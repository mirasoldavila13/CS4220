# SpotifyAPI_Midterm


Note to run: 

To search artists: node cli.js search --artists Jon

To search featured playlists: node cli.js search --featured

To search new Releases: node cli.js search --newRelease

To search album + artist: node cli.js seach --album lil pump --artist lil pump

