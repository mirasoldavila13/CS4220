import java.util.ArrayList;

public class Ingredient {
 //Each ingredient has a name, isPurchased, and a quantity.
	String iname, isPurchased, quantity;
	static ArrayList<Recipe> cake = new ArrayList<>();
	static ArrayList<Recipe> hamburger = new ArrayList<>();
	//debating if I should have an arraylist or not.
	
	public Ingredient(String iname, String isPurchased, String quantity) {
		super();
		this.iname = iname;
		this.isPurchased = isPurchased;
		this.quantity = quantity;
	}
	
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getIsPurchased() {
		return isPurchased;
	}
	public void setIsPurchased(String isPurchased) {
		this.isPurchased = isPurchased;
	}
	
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public static ArrayList<Recipe> getCake() {
		return cake;
	}
	public static void setCake(ArrayList<Recipe> cake) {
		Ingredient.cake = cake;
	}
	public static ArrayList<Recipe> getHamburger() {
		return hamburger;
	}
	public static void setHamburger(ArrayList<Recipe> hamburger) {
		Ingredient.hamburger = hamburger;
	}


}
