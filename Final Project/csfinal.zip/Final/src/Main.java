import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Main extends Application implements EventHandler{
	Scanner scan = new Scanner(System.in);
	Stage thestage;
	Scene scene1, scene2;
	Button importantRecipe, buyIngredient;
	
	
	public static void main(String[] args) {
		// create menu Import Recipe, and Buy Ingredients
		launch(args);
			
		}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		//create first stage
		thestage = primaryStage;
		Label mainMenu = new Label("Grocery Shopping Program");
		
		importantRecipe = new Button("Important Recipe");// assuming the ingredients that we already have
		importantRecipe.setId("important-ingredients");
		importantRecipe.setOnAction(this);
		
		
		buyIngredient = new Button("Buy Ingredients");// ingredients that are missing for the recipe
		buyIngredient.setId("buy-ingredients");
		buyIngredient.setOnAction(e -> thestage.setScene(scene2));
		
		//create VBox
		VBox root = new VBox(10);
		root.getChildren().addAll(mainMenu, importantRecipe, buyIngredient);
		root.setAlignment(Pos.CENTER);
				
		scene1 = new Scene(root, 350, 300);
		String css1 = Main.class.getResource("myStylecss.css").toExternalForm();
		scene1.getStylesheets().add(css1);
		
		
		
		//scene 2 where user gets to pick their ingredients
	
		//create pane
		Pane pane = new Pane();
		
		//checkboxes for user to buy ingredients
		CheckBox  box1 = new CheckBox("Flour");
		CheckBox  box2 = new CheckBox("Sugar");
		CheckBox  box3 = new CheckBox("Vanilla Extract");
		CheckBox  box4 = new CheckBox("Eggs");
		CheckBox  box5 = new CheckBox("Milk");
		CheckBox  box6 = new CheckBox("Strawberry");
		CheckBox  box7 = new CheckBox("Ground Beef");
		CheckBox  box8 = new CheckBox("Salt");
		CheckBox  box9 = new CheckBox("Cheese");
		CheckBox  box10 = new CheckBox("Lettuce");
		CheckBox  box11 = new CheckBox("Secret Sauce");
		

		//create rectangless
		
		Rectangle rec1 = new Rectangle(10,10,10,10);//water
		Rectangle rec2 = new Rectangle(10,10,10,10);//flour
		Rectangle rec3 = new Rectangle(10,10,10,10);//sugar
		Rectangle rec4 = new Rectangle(10,10,10,10);//vanilla extract
		Rectangle rec5 = new Rectangle(10,10,10,10);//egg
		Rectangle rec6 = new Rectangle(10,10,10,10);//milk
		Rectangle rec7 = new Rectangle(10,10,10,10);//strawberry
		Rectangle rec8 = new Rectangle(10,10,10,10);//salt
		Rectangle rec9 = new Rectangle(10,10,10,10);//pepper
		Rectangle rec10 = new Rectangle(10,10,10,10);//cheese
		Rectangle rec11 = new Rectangle(10,10,10,10);//lettuce
		Rectangle rec12 = new Rectangle(10,10,10,10);//buns
		Rectangle rec13 = new Rectangle(10,10,10,10);//secret sause
		Rectangle rec14 = new Rectangle(10,10,10,10);
		
		//suppose to have a setOnAction for each rectangle where it displays the recipe name, ingredient and the quantity
		//within the event handler I'm suppose to have an if statement for each rectangle where the event sour
		VBox root1 = new VBox(10);
		root1.getChildren().addAll(box1, box2, box3, box4,box5,box6,box7, box8, box9, box10,box11);
		
		pane.getChildren().addAll(root1, rec1, rec2, rec3, rec4, rec5, rec6, rec7, rec8, rec9, rec10, rec11, rec12, rec13, rec14);
		
		//need to display the rectangles
		
		
		
		scene2 = new Scene(pane, 350, 300);
		String css2 = Main.class.getResource("style.css").toExternalForm();
		scene2.getStylesheets().add(css2);
		
		
		thestage.setScene(scene1);//default
		thestage.show();
	}

	@Override
	public void handle(Event event) {
		if(event.getSource()== importantRecipe){
			//Allow the user to choose and import the CSV file specified at the bottom. This will contain the recipe and ingredient info
			//user cna import their own file 
			FileChooser fileChooser = new FileChooser();
             
	            
		}
		
	}
	
    
     

}
