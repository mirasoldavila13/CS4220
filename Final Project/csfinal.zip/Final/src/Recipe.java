
public class Recipe {
	//to represent a single recipe with ingredients
	String recipeName;

	public Recipe(String recipeName) {
		super();
		this.recipeName = recipeName;
	}

	public String getRecipeName() {
		return recipeName;
	}

	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

	
}
